<section class="container text-center mt-5 photo">
    <div class="row tt">
        <div class="col-sm-5">
            <?php dynamic_sidebar('lineleft');?>
        </div>
        <div class="col-sm-2">
        <?php dynamic_sidebar('phototitle');?>
        </div>
        <div class="col-sm-5">
        <?php dynamic_sidebar('lineright');?>
        </div>
    </div>
    <div class="row mt-4">
    <div class="col-sm-3">
        <div class="card" style="width: 16rem;">
        <?php dynamic_sidebar('photocard1');?>
        </div>
        </div>
        <div class="col-sm-3">
        <div class="card" style="width: 16rem;">
        <?php dynamic_sidebar('photocard2');?>
        </div>
        </div>
        <div class="col-sm-3">
        <div class="card" style="width: 16rem;">
        <?php dynamic_sidebar('photocard3');?>
        </div>
        </div>
        <div class="col-sm-3">
        <div class="card" style="width: 16rem;">
        <?php dynamic_sidebar('photocard4');?>
        </div>
        </div>
    </div>
</section>