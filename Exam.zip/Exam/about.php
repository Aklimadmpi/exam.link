<?php
/**
 * Template Name: about 
*/ 
get_header();?>

<!-- hero part start -->
<section class="container text-center mt-5 hero">
    <div class="row">
        <?php dynamic_sidebar('herotitle');?>
    </div>
    <div class="row mt-5">
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('herocard1');?>
        </div>
        </div>
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('herocard2');?>
        </div>
        </div>
        <div class="col-sm-4">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('herocard3');?>
        </div>
        </div>
    </div>
</section>
<!-- hero part end -->

<!-- news part start -->
<section class="container mt-5 news">
    <div class="row text-center">
    <div class="col-sm-5">
            <?php dynamic_sidebar('lineleft1');?>
        </div>
        <div class="col-sm-2">
        <?php dynamic_sidebar('phototitle1');?>
        </div>
        <div class="col-sm-5">
        <?php dynamic_sidebar('lineright1');?>
        </div>
    </div>
    <div class="row">
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <?php
    $qry1 = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'slider'
    ]);
    ?>
  <div class="carousel-inner">
    <?php
    $x = 0 ;
    while($qry1->have_posts()){$qry1->the_post();
    $x++;
    ?>
    <div class="carousel-item <?=($x==1)? 'active' : ''?>">
    <?php the_title();?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php }?>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </div>
</section>
<!-- news part end -->

<?php get_footer();?>