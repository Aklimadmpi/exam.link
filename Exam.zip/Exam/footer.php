<!-- footer part start -->
<footer class="container-fluid mt-5 foot">
    <div class="container">
    <div class="row ft">
        <div class="col-sm-8">
            <?php dynamic_sidebar('ftleft');?>
        </div>
        <div class="col-sm-4">
        <?php dynamic_sidebar('ftright');?>
        </div>
    </div>
    <div class="row fb">
    <div class="col-sm-6">
            <?php dynamic_sidebar('fbleft');?>
        </div>
        <div class="col-sm-6">
        <?php dynamic_sidebar('fbright');?>
        </div>
    </div>
    </div>
</footer>
<!-- footer part end -->
    

<?php wp_footer();?>
</body>
</html>